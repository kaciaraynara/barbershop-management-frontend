import xss from 'xss';

/**
 * Sanitiza uma string para prevenir ataques XSS
 * @param input String para sanitizar
 * @returns String sanitizada
 */
export function sanitizeString(input: string | null | undefined): string {
  if (input === null || input === undefined) {
    return '';
  }
  return xss(input);
}

/**
 * Sanitiza um objeto para prevenir ataques XSS
 * @param obj Objeto para sanitizar
 * @returns Objeto com todas as strings sanitizadas
 */
export function sanitizeObject<T>(obj: T): T {
  if (!obj || typeof obj !== 'object') {
    return obj;
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => 
      typeof item === 'string' 
        ? sanitizeString(item) as unknown as any
        : sanitizeObject(item)
    ) as unknown as T;
  }
  
  const result: Record<string, any> = {};
  
  Object.entries(obj as Record<string, any>).forEach(([key, value]) => {
    if (typeof value === 'string') {
      result[key] = sanitizeString(value);
    } else if (Array.isArray(value)) {
      result[key] = value.map(item => 
        typeof item === 'string' 
          ? sanitizeString(item) 
          : (item !== null && typeof item === 'object' ? sanitizeObject(item) : item)
      );
    } else if (value !== null && typeof value === 'object') {
      result[key] = sanitizeObject(value);
    } else {
      result[key] = value;
    }
  });
  
  return result as unknown as T;
}