# Documentação do Backend

O backend do BarberShop Management System foi desenvolvido utilizando Node.js com Express e TypeScript, oferecendo uma API RESTful para comunicação com o frontend.

## Estrutura de Diretórios

```
server/
├── index.ts          # Ponto de entrada da aplicação
├── routes.ts         # Definição de rotas da API
├── storage.ts        # Interface e implementação de armazenamento
└── vite.ts           # Configuração do Vite para desenvolvimento
```

## Tecnologias Principais

- **Node.js**: Ambiente de execução JavaScript
- **Express**: Framework web para criação de APIs
- **TypeScript**: Linguagem de programação tipada
- **Drizzle ORM**: ORM SQL com suporte a TypeScript
- **Zod**: Validação de esquemas

## Armazenamento de Dados

O sistema utiliza uma implementação de armazenamento em memória (`MemStorage`) como referência, que pode ser facilmente substituída por uma implementação de banco de dados real (PostgreSQL, MySQL, etc.) seguindo a mesma interface.

### Interface de Armazenamento (IStorage)

A interface `IStorage` define todos os métodos necessários para interagir com os dados da aplicação:

```typescript
export interface IStorage {
  // Barbeiros
  getBarbers(): Promise<Barber[]>;
  getBarber(id: number): Promise<Barber | undefined>;
  createBarber(barber: InsertBarber): Promise<Barber>;
  updateBarber(id: number, barber: Partial<InsertBarber>): Promise<Barber | undefined>;
  deleteBarber(id: number): Promise<boolean>;
  
  // Serviços
  getServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service | undefined>;
  deleteService(id: number): Promise<boolean>;
  
  // Clientes
  getClients(): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;
  
  // Agendamentos
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsWithDetails(): Promise<AppointmentWithDetails[]>;
  getAppointmentsByDate(date: string): Promise<AppointmentWithDetails[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAppointmentWithDetails(id: number): Promise<AppointmentWithDetails | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  
  // Produtos
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Vendas
  getSales(): Promise<Sale[]>;
  getSalesWithDetails(): Promise<SaleWithDetails[]>;
  getSalesByDate(date: string): Promise<SaleWithDetails[]>;
  getSale(id: number): Promise<Sale | undefined>;
  getSaleWithDetails(id: number): Promise<SaleWithDetails | undefined>;
  createSale(sale: InsertSale): Promise<Sale>;
  updateSale(id: number, sale: Partial<InsertSale>): Promise<Sale | undefined>;
  deleteSale(id: number): Promise<boolean>;
  
  // Dashboard
  getDashboardData(): Promise<{
    todayAppointments: number;
    todayClientsServed: number;
    todayRevenue: number;
    todayProductsSold: number;
    barberPerformance: { name: string; clients: number }[];
    topServices: { name: string; percentage: number }[];
  }>;
}
```

### Implementação em Memória

A classe `MemStorage` implementa a interface `IStorage` utilizando Maps como estrutura de dados para armazenar as informações em memória. Esta implementação inclui:

- Métodos CRUD para todas as entidades
- Métodos específicos para obter informações do dashboard
- Dados iniciais para testes (seed data)

## Endpoints da API

A API REST é organizada em endpoints por tipo de recurso:

### Barbeiros
- `GET /api/barbers`: Lista todos os barbeiros
- `GET /api/barbers/:id`: Obtém detalhes de um barbeiro específico
- `POST /api/barbers`: Cria um novo barbeiro
- `PATCH /api/barbers/:id`: Atualiza um barbeiro existente
- `DELETE /api/barbers/:id`: Remove um barbeiro

### Serviços
- `GET /api/services`: Lista todos os serviços
- `GET /api/services/:id`: Obtém detalhes de um serviço específico
- `POST /api/services`: Cria um novo serviço
- `PATCH /api/services/:id`: Atualiza um serviço existente
- `DELETE /api/services/:id`: Remove um serviço

### Clientes
- `GET /api/clients`: Lista todos os clientes
- `GET /api/clients/:id`: Obtém detalhes de um cliente específico
- `POST /api/clients`: Cria um novo cliente
- `PATCH /api/clients/:id`: Atualiza um cliente existente
- `DELETE /api/clients/:id`: Remove um cliente

### Agendamentos
- `GET /api/appointments`: Lista todos os agendamentos
- `GET /api/appointments/details`: Lista todos os agendamentos com detalhes
- `GET /api/appointments/date/:date`: Lista agendamentos por data
- `GET /api/appointments/:id`: Obtém detalhes de um agendamento específico
- `GET /api/appointments/details/:id`: Obtém detalhes completos de um agendamento
- `POST /api/appointments`: Cria um novo agendamento
- `PATCH /api/appointments/:id`: Atualiza um agendamento existente
- `DELETE /api/appointments/:id`: Remove um agendamento

### Produtos
- `GET /api/products`: Lista todos os produtos
- `GET /api/products/:id`: Obtém detalhes de um produto específico
- `POST /api/products`: Cria um novo produto
- `PATCH /api/products/:id`: Atualiza um produto existente
- `DELETE /api/products/:id`: Remove um produto

### Vendas
- `GET /api/sales`: Lista todas as vendas
- `GET /api/sales/details`: Lista todas as vendas com detalhes
- `GET /api/sales/date/:date`: Lista vendas por data
- `GET /api/sales/:id`: Obtém detalhes de uma venda específica
- `GET /api/sales/details/:id`: Obtém detalhes completos de uma venda
- `POST /api/sales`: Cria uma nova venda
- `PATCH /api/sales/:id`: Atualiza uma venda existente
- `DELETE /api/sales/:id`: Remove uma venda

### Dashboard
- `GET /api/dashboard`: Obtém dados para o dashboard

## Validação de Dados

Todas as requisições que envolvem criação ou atualização de dados são validadas usando esquemas Zod, definidos no arquivo `shared/schema.ts`. Isso garante que:

1. Dados inválidos não sejam processados
2. Erros sejam retornados de forma clara e consistente
3. A tipagem seja mantida em todo o sistema

## Tratamento de Erros

O backend implementa um middleware global para tratamento de erros que:

1. Captura exceções não tratadas
2. Formata mensagens de erro de forma amigável
3. Retorna códigos HTTP apropriados
4. Registra erros no console para depuração

## Medidas de Segurança

- **Helmet**: Proteção de cabeçalhos HTTP
- **Validação de Entrada**: Prevenção de injeção de dados maliciosos
- **Sanitização**: Prevenção de XSS em dados retornados

## Extensibilidade

O backend foi projetado para ser facilmente extensível:

1. **Storage Abstraction**: Fácil substituição da implementação de armazenamento
2. **Modularidade**: Separação clara de responsabilidades
3. **Tipagem Forte**: Interfaces bem definidas

## Requisitos para Produção

Para um ambiente de produção, recomenda-se:

1. Substituir a implementação `MemStorage` por um banco de dados persistente
2. Implementar autenticação e autorização
3. Configurar CORS adequadamente
4. Adicionar logging mais detalhado
5. Implementar rate limiting para proteção contra abuso