# Guia de Implantação

Este documento fornece instruções detalhadas para implantar o BarberShop Management System em ambientes de produção.

## Opções de Implantação

O sistema foi projetado para ser implantado de duas maneiras:

1. **Implantação Monolítica**: Backend e frontend hospedados no mesmo servidor
2. **Implantação Separada**: Backend e frontend em servidores diferentes

## Implantação Monolítica

### Requisitos
- Node.js 16+ instalado
- NPM ou Yarn instalado
- Git instalado (opcional)

### Passos para Implantação

1. Clone o repositório ou faça upload dos arquivos para o servidor:
```bash
git clone https://github.com/seu-usuario/barbershop-management.git
cd barbershop-management
```

2. Instale as dependências:
```bash
npm install
```

3. Compile o projeto para produção:
```bash
npm run build
```

4. Inicie o servidor:
```bash
npm start
```

O aplicativo estará disponível na porta 5000 (ou conforme configurado em variáveis de ambiente).

### Configuração em Plataformas Específicas

#### Render

1. Crie uma nova aplicação Web Service no Render
2. Conecte ao repositório GitHub
3. Configure as seguintes opções:
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Environment Variables**: Configure conforme necessário
4. Clique em "Create Web Service"

#### BackApp4

1. Crie uma nova aplicação Node.js no BackApp4
2. Configure o Git como método de implantação
3. Configure as seguintes opções:
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Node.js Version**: Selecione a versão mais adequada (16+)
4. Configure as variáveis de ambiente necessárias
5. Clique em "Deploy"

## Implantação Separada (Frontend e Backend)

### Backend (Render/BackApp4)

1. Configure o repositório para o backend:
```bash
git clone https://github.com/seu-usuario/barbershop-management.git
cd barbershop-management
```

2. Crie um arquivo `render.yaml` ou similar para configurar a implantação:
```yaml
services:
  - type: web
    name: barbershop-api
    env: node
    buildCommand: npm install && npm run build
    startCommand: npm run start:api
    envVars:
      - key: NODE_ENV
        value: production
      - key: API_URL
        value: https://sua-api.render.com
```

3. Configure as variáveis de ambiente necessárias
4. Faça deploy seguindo as instruções da plataforma

### Frontend (Vercel)

1. Faça login no Vercel e crie um novo projeto
2. Importe o repositório do GitHub
3. Configure as seguintes opções:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build:client`
   - **Output Directory**: `dist/client`
   - **Development Command**: `npm run dev:client`
4. Configure as variáveis de ambiente:
   - `VITE_API_URL`: URL do backend (ex: https://sua-api.render.com)
5. Clique em "Deploy"

## Variáveis de Ambiente

### Variáveis Obrigatórias
- `NODE_ENV`: Ambiente de execução (`development`, `production`)
- `PORT`: Porta onde o servidor será executado (padrão: 5000)

### Variáveis Opcionais
- `API_URL`: URL base da API (para implantação separada)
- `VITE_API_URL`: URL da API (para o frontend em implantação separada)
- `DATABASE_URL`: URL de conexão com o banco de dados (quando usar banco de dados persistente)

## Configuração de Banco de Dados (Opcional)

Para substituir o armazenamento em memória por um banco de dados persistente:

### PostgreSQL

1. Crie um banco de dados PostgreSQL
2. Configure a variável de ambiente `DATABASE_URL`
3. Atualize a implementação de `IStorage` para usar PostgreSQL

### MySQL

1. Crie um banco de dados MySQL
2. Configure a variável de ambiente `DATABASE_URL`
3. Atualize a implementação de `IStorage` para usar MySQL

## Considerações de Produção

### Segurança
- Ative HTTPS para todas as conexões
- Configure corretamente o CORS (para implantação separada)
- Implemente mecanismos de autenticação e autorização
- Considere adicionar rate limiting para proteção contra abusos

### Performance
- Configure corretamente o cache para recursos estáticos
- Considere usar um CDN para arquivos estáticos
- Otimize consultas ao banco de dados
- Configure compressão gzip/brotli

### Monitoramento
- Configure logs detalhados
- Implemente monitoramento de saúde do aplicativo
- Configure alertas para erros críticos
- Implemente ferramentas de análise de desempenho

### Backup
- Configure backups regulares do banco de dados
- Implemente procedimentos de recuperação
- Teste os procedimentos de backup/restore periodicamente

## Resolução de Problemas

### Problemas Comuns

1. **Erro "Port in use"**:
   - Verifique se outro processo está usando a porta configurada
   - Altere a porta nas variáveis de ambiente

2. **Erro de conexão com banco de dados**:
   - Verifique se o banco de dados está acessível
   - Confirme as credenciais nas variáveis de ambiente
   - Verifique regras de firewall

3. **Erro 404 em rotas do frontend**:
   - Certifique-se de que todas as requisições são redirecionadas para o index.html
   - Verifique a configuração do servidor web

4. **Erro de CORS**:
   - Configure corretamente os cabeçalhos CORS no backend
   - Verifique se a origem da requisição está permitida

## Atualizações e Manutenção

Para atualizar o aplicativo em produção:

1. Faça pull das alterações mais recentes ou faça upload dos novos arquivos
2. Instale dependências atualizadas: `npm install`
3. Recompile o projeto: `npm run build`
4. Reinicie o servidor

Para plataformas como Render e Vercel, o processo de atualização geralmente é automatizado por meio de integração contínua quando novos commits são feitos no repositório.